export declare function decode(
  bytes: number[],
  twoS: number
): Uint8ClampedArray;

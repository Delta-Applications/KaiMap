import { BitMatrix } from "../BitMatrix";
import { DecodedQR } from "./decodeData";
export declare function decode(matrix: BitMatrix): DecodedQR;
